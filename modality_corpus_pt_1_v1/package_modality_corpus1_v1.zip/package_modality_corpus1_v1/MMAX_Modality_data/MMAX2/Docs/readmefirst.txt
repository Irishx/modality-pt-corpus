Note: The documentation in this directory is slightly (though not substantially) outdated. In particular, contrary to the description in the 'Quickstart' guide, the mmaxkey.jar file is no longer required.
All other descriptions are still valid. However, since MMAX2 has seen some updates since the version for which this documentation was created, not all features might be described.

New and up-to-date versions of the   documentation will be made available at http://mmax2.net.

