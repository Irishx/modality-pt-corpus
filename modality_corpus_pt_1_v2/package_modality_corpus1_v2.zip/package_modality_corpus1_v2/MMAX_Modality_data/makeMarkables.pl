#!/usr/bin/perl -w
#
# nov,2006, Iris
# pasing the imix data 
#to transform them to mmax-format.
#
#eventueel nog nadenken over meer sofisticated head-feature
#
# we have iconv for converting iso to utf8
# iconv -t "UTF-8" -f "ISO-8859-1" SubsetProcessed/s51.xml> s51.utf8.xml 

my $line;
my $string;
my (@fields,@tokens);
my $wordteller=0;
my $steller=0;
my $posteller=-1;
my ($tag, $words);
my (%mark_start);
my ($startId, $endId);
my @stack;
my $mteller=0;
my ($lastword, $id);
my $file = $ARGV[0];

print "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<!DOCTYPE markables SYSTEM \"markables.dtd\">\n<markables xmlns=\"www.eml.org/NameSpaces/coref\">\n";


print "</markables>\n";


