#!/usr/bin/perl -w
#
#October,2021 adaptation to change the recognition of special chars that cannot be handled by mmax: & < >
# nov,2006, Iris
# pasing the input data
#to transform them to mmax-format.
#


my $line;
my $string;
my $tag;
my (@fields,@tokens);
my $wordteller=0;
my $steller=0;
my $posteller=-1;

my $file = $ARGV[0];
my $wordfile= $ARGV[1];
my $sentencefile = $ARGV[2];
my ($start,$end);


#$file = "/Users/iris/CLUL/Werk/Modality/Data/Preparation/mod_sentences$num";
#$wordfile ="/Users/iris/CLUL/Werk/Modality/MMAX_Modality/Basedata/mod_sentences_$num"."_words.xml";
#$sentencefile =  "/Users/iris/CLUL/Werk/Modality/MMAX_Modality/Markables/mod_sentences_$num"."_sentence_level.xml";

open(TEXT,"$file") || die "kan $file niet openen";
open(WORDS,">$wordfile" )|| die "kan $wordfile niet openen";
open(SENT,">$sentencefile") || die "kan $sentencefile niet openen";

print   WORDS "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<!DOCTYPE words SYSTEM \"words.dtd\">\n<words>\n";

print SENT  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<!DOCTYPE markables SYSTEM \"markables.dtd\">\n<markables xmlns=\"www.eml.org/NameSpaces/sentences\">\n";

 while(<TEXT>)
{
  $line = $_;
  chomp($line);
  if($line =~ /\w+/)
  {

  if($wordteller>0) {
  print SENT "<markable id=\"markable_$steller\" span=\"word_$start..word_$end\" mmax_level=\"sentences\" />\n";  }
    $start= $wordteller+1;
    $steller++;

   @tokens = split /\s+/, $line;
    foreach my $tok (@tokens)
    {
	  if($tok =~ /.+/){
	      $wordteller++;
    if($tok =~ /[\&|\<|\>]/){$tok =~ s/\&/\&AMP;/g; $tok =~ s/\</\&LT;/g; $tok =~ s/\>/\&GT;/g; print STDERR "$tok\n";}

		  print WORDS "   <word id=\"word_$wordteller\">$tok</word>\n";
	     }
    }
    $end= $wordteller;
  }
}
close(TEXT);

print WORDS "</words>\n";

print  SENT "<markable id=\"markable_$steller\" span=\"word_$start..word_$end\" mmax_level=\"sentences\" />\n";
print SENT "</markables>\n";

close(WORDS);
close(SENT);
