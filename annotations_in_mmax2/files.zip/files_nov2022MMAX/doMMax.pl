#!/usr/bin/perl
#Iris, 2011-2013

#MMAX data conversion. MMAX needs a lot of files, it needs to have
# these dirs: Customizations/ Styles/ Schemes/
# the dtds in the dirs: Basedate/words.dtd Markables/markables.dtd
# and very important: common_paths.xml that tells MMAX which styles, customizations and sheets to use.

# this script here then creates the word file, the sentence file and writes the file.mmax that tells MMAX which file to open.

use warnings;
use strict;

my ($name, $nwords, $nmarks);

my $filename = $ARGV[0] || die "no argument is given: script filename outpathdir\n";
my $outpath = $ARGV[1];



#make words-file and the sentence markable file with the script makeWords.pl
$nwords = $filename;
$nwords .= "_words.xml";
$nmarks = $filename;
$nmarks .= "_sentence_level.xml";
system("perl makeWords.pl $filename  $outpath/Basedata/$nwords  $outpath/Markables/$nmarks");
print STDERR  "running now: perl makeWords.pl $filename  $outpath/Basedata/$nwords  $outpath/Markables/$nmarks\n";

#write the .mmax file
  &writeMmax("$filename");


#MMAX needs this core file that tells him how the file is named.
sub writeMmax{

 my $name = $_[0];

 open(OUT,">$outpath/$name.mmax");
 $name .= "_words.xml";
 print OUT "<?xml version=\"1.0\"?>\n<mmax_project>\n<words>$name</words>\n</mmax_project>\n";
 close(OUT);

}
